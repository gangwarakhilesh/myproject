package com.akhil.employee.service;

import com.akhil.employee.entity.Employee;
import com.akhil.employee.exception.ResourceAlreadyExistsException;
import com.akhil.employee.exception.ResourceNotFoundException;
import com.akhil.employee.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository)
    {

        this.employeeRepository=employeeRepository;
    }

    public Employee createEmployee(Employee employee)
    {
        if (employee.getId() != null &&
                employeeRepository.existsById(employee.getId()))
        {
            throw new ResourceAlreadyExistsException("Employee with this ID already exists: " +employee.getId());
        }
        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployee(Employee employee)
    {
        return employeeRepository.findAll();
    }

    public Employee getById(Long id)
    {
        return employeeRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Employee not found with Id: "+id));
    }


    public Employee updateEmployee(long id, Employee employee)
    {
        Employee emp = employeeRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Employee not found by Id: "+id));

        emp.setName(employee.getName());
        emp.setCompany(employee.getCompany());
        emp.setEmailId(employee.getEmailId());
        emp.setSalary(employee.getSalary());
        emp.setPhone(employee.getPhone());
        return employeeRepository.save(emp);
    }

    public Employee deleteEmployee(long id)
    {
        Employee emp = employeeRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Employee not found by Id: "+id));
        employeeRepository.deleteById(id);
        return emp;
    }
}
