package com.akhil.employee.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())   // 👈 CSRF disable
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().permitAll()   // 👈 Login required nahi
                );

        return http.build();
    }
}
