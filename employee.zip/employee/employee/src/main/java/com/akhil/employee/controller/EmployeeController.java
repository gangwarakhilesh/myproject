package com.akhil.employee.controller;


import com.akhil.employee.entity.Employee;
import com.akhil.employee.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController
{
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @PostMapping("/save")
    public Employee createEmployee(@Valid @RequestBody Employee employee)
    {
        return employeeService.createEmployee(employee);
    }

    @GetMapping("/all")
    public List<Employee> getAllEmployee(Employee employee)
    {
        return employeeService.getAllEmployee(employee);
    }

    @GetMapping("/{id}")
    public Employee getById(@PathVariable Long id)
    {
        return employeeService.getById(id);
    }

    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable long id, @RequestBody Employee employee)
    {
        return employeeService.updateEmployee(id, employee);
    }

    @DeleteMapping("/{id}")
    public Employee deleteEmployee(@PathVariable long id)
    {
        return employeeService.deleteEmployee(id);
    }
}
