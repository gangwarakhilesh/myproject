package com.akhil.employee.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.*;

@Entity
@Table(name="employess")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Employee
{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_no")
    @Id
    private Long id;

    @NotBlank(message = "Name cannot be null or empty")
    @Column(nullable = false)
    private String name;

    @NotBlank(message = "Company cannot be null or empty")
    @Column(nullable = false)
    private String company;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Please provide a valid email address")
    @Column(name="email_id", nullable = false, unique = true)
    private String emailId;

    @NotNull(message = "Salary is mandatory")
    @Column(nullable = false)
    private Double salary;

    @NotBlank(message = "Phone number is mandatory")
    @Pattern(regexp = "^[6-9][0-9]{9}$", message = "Enter valid 10 digit Indian phone number")
    @Column(name="phone_no", nullable = false)
    private String phone;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
